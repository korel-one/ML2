# MACHINE LEARNING PROJECT-2
##### Nicolas Goncalves, Roman Rudnik, Sergii Shynkaruk

In this project we applied three approaches in order to perform road segmentation of satellite images. Several binary classifiers
were developed: 
 - linear: Logistic Regression with polynomial features of degree 2
 - decision tree based: Gradient Boosting 
 - deep learning: Convolutional Neural Networks
 
As a final model we keep the CNN based model, as we reached an accuracy ~90%.

### Environment
- Python 3.6
- Anaconda 4.3
- We set up a virtual environment by following the instructions detailed in: http://inmachineswetrust.com/posts/deep-learning-setup/
- Keras 1.1.2
- Tensorflow 0.12

Keras is a higher level abstraction which uses TensorFlow as its backend.

### Computational Facilities / Configuration
- Windows 10 Pro
- Intel(R)_Core(TM)_i7-3612QM_CPU_@_2.10GHz; 8 Cores
- RAM 8 GB
- System type x64-based processor

CNN model has been trained on CPU, with epochs number = 22

### Run
We provide three directories for each model; to run them put the training and testing set inside the appropriate directory.
The submission is provided for each model to avoid running model again - dummy_submission.csv.

## CNN directory

# directories
- predict_training, contains ground truth of the predicted training images
- testing, same for testing images
- training, contains training groundtruth

# files
- helpers.py, mask_to_submission.py - auxiliary functions
- model.py - CNN architecture
- run.py - generates the submission file from the testing prediction (provided in testing directory)
- model.h5 - weights obtained after training phase
- train.ipynb - jupyter notebook to perform the training
- generate_groundtruth_and_submit.ipynb - from model.h5 it creates the predicted groundtruth and csv file for submission
(it is not necesary to run it, because predicted groundtruth are provided; run run.py instead)
- fast_training_prediction.ipynb - it gives the accuracy of the model (uses predict_training)
- slow_predict_training.ipynb - create predict_training and gives the accuracy of the model
(it is not necesary to run it, because predict_training is provided)

### Remarks for train.ipynb
Training phase took > 10 hours with the mentioned computational facilities during 22 epochs.
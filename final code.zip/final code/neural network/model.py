from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Convolution2D, MaxPooling2D
from keras.optimizers import Adam
from keras.utils import np_utils
from keras import backend as K
from keras.regularizers import l2
from keras.layers import LeakyReLU
from keras.callbacks import ReduceLROnPlateau, EarlyStopping
from helpers import *

from random import randint
from skimage import transform

# Add symmetric padding to the training image set
def pad_training(X, Y, padding):
    _X = np.zeros((X.shape[0], X.shape[1] + 2*padding, X.shape[2] + 2*padding, X.shape[3]))
    _Y = np.zeros((Y.shape[0], Y.shape[1] + 2*padding, Y.shape[2] + 2*padding))

    for i in range(X.shape[0]):
        _X[i] = pad_image(X[i], padding)
        _Y[i] = pad_image(Y[i], padding)
    return (_X, _Y)

class Model:
    def __init__(self):
        self.window_size = 48
        self.patch_size = 16
        self.pool_size = (2, 2)
        self.class_number = 2
        self.padding = 16 #int((self.window_size - self.patch_size)/2)
        self.batch_size = 125
        self.epochs = 20
        
        self.model = Sequential()

        """ Input layer:
        
        Sequential model requires an input shape to be set up in the first layer.
        Input shape parameter is the shape of 1 sample (depth, width, height)
        """
        self.model.add(Convolution2D(64, 5, 5, # 64 5x5 filters
            border_mode='same', 
            input_shape=(self.window_size, self.window_size, 3))) 
        self.model.add(LeakyReLU(alpha=0.1))
        self.model.add(MaxPooling2D(pool_size=self.pool_size, border_mode='same'))
        self.model.add(Dropout(0.25))
        
        # Add 3 hidden convolutional layers
        
        self.model.add(Convolution2D(128, 3, 3, # 128 3x3 filters
            border_mode='same'))
        self.model.add(LeakyReLU(alpha=0.1))
        self.model.add(MaxPooling2D(pool_size=self.pool_size, border_mode='same'))
        self.model.add(Dropout(0.25))

        self.model.add(Convolution2D(256, 3, 3, # 256 3x3 filters
            border_mode='same'))
        self.model.add(LeakyReLU(alpha=0.1))
        self.model.add(MaxPooling2D(pool_size=self.pool_size, border_mode='same'))
        self.model.add(Dropout(0.25))

        self.model.add(Convolution2D(256, 3, 3, # 256 3x3 filters
            border_mode='same'))
        self.model.add(LeakyReLU(alpha=0.1))
        self.model.add(MaxPooling2D(pool_size=self.pool_size, border_mode='same'))
        self.model.add(Dropout(0.25))
        
        """ Add a fully connected layer of 128 neurons.
            Output layer size => class_number = 2
        """

        # regularization factor
        _lambda = 1e-6

        self.model.add(Flatten())
        self.model.add(Dense(128, W_regularizer=l2(_lambda)))
        self.model.add(LeakyReLU(alpha=0.1))
        self.model.add(Dropout(0.5))

        # l2 regularization used for weights
        self.model.add(Dense(self.class_number, W_regularizer=l2(_lambda)))

    def train(self, X, Y):
        print('Training start: shape = ', X.shape)

        samples_per_epoch = int(X.shape[0]*X.shape[1]*X.shape[2]/256)

        XY_pad = pad_training(X, Y, self.padding)

        X = XY_pad[0]
        Y = XY_pad[1]

        # improves numerical stability
        def categorical_crossentropy(y_true, y_pred):
            return K.categorical_crossentropy(y_pred, y_true, from_logits=True)        

        # optimizer with initial learning rate
        adam = Adam(lr=0.001)
        
        # configure the learning process with loss function and optimizer
        self.model.compile(loss=categorical_crossentropy, optimizer=adam, metrics=['accuracy'])

        # make it deterministic
        np.random.seed(3)

        """ 
        Workin in parallel thread, it fits the model on data yielded batch-by-batch.
        Takes randomly batch_size samples from patches and labels. 
        To feed into each epoch until epoch hits samples_per_epoch limit.
        """
        def mb_generator():
            THRESHOLD = 0.25

            ws = int(self.window_size/2)
            ps = int(self.patch_size/2)

            while True:

                """ 
                Create empty arrays to contain batch of patches and labels
                performance: np.empty is marginally faster than np.zeros 
                """
                batch_patches = np.empty((self.batch_size, self.window_size, self.window_size, 3))
                batch_labels = np.empty((self.batch_size, 2))

                for i in range(self.batch_size):

                    # choose random image
                    img_i = np.random.choice(X.shape[0])
                    shape = X[img_i].shape

                    # extract random patch
                    rand_pos = np.random.randint(ws, high=(shape[0] - ws), size=2)

                    patch = X[img_i][rand_pos[0] - ws : rand_pos[0] + ws,
                                    rand_pos[1]- ws : rand_pos[1] + ws]

                    gt_patch = Y[img_i][rand_pos[0] - ps : rand_pos[0] + ps,
                                        rand_pos[1] - ps : rand_pos[1] + ps]

                    # label depends on the content of the patch, so rotation by 90° preserves it
                    label = (np.array([np.mean(gt_patch)]) > THRESHOLD) * 1

                    # as an image augmentation we randomly rotate a patch by 90° * factor
                    rotate_factor = randint(0, 3)
                    patch = transform.rotate(patch, 90*rotate_factor)

                    # converts class vector - label to binary class matrix
                    label = np_utils.to_categorical(label, self.class_number)

                    batch_patches[i] = patch
                    batch_labels[i] = label

                yield (batch_patches, batch_labels)

        # callback: reduce learning rate when a metric has stopped improving
        reduce_lr = ReduceLROnPlateau(monitor='acc', factor=0.5, patience=5,
            verbose=1, mode='auto', epsilon=0.0001, cooldown=0, min_lr=0)

        # callback: stop training when a monitored quantity has stopped improving
        stop_cb = EarlyStopping(monitor='acc'
            , min_delta=0.0001
            , patience=11
            , verbose=1
            , mode='auto')

        """ 
        fit_generator() serves to train the model in a more memory efficient way
        It cleans up the used data and move on repeating the same flow in a new epoch.
        """
        try:
            self.model.fit_generator(mb_generator(),
                samples_per_epoch=samples_per_epoch,
                nb_epoch=self.epochs,
                verbose=1,
                callbacks=[reduce_lr, stop_cb])
        except KeyboardInterrupt:
            pass

        print('Training completed')
    
    def save(self, file_name):
        self.model.save_weights(file_name)
        
    def load(self, file_name):
        self.model.load_weights(file_name)

    """ Classifies a testing image set.

    Input: testing image set
    Output: the list of predictions
    """
    def predict(self, X):
        # split the images into patches
        img_patches = create_patches(X, self.patch_size, 16, self.padding)
        
        # run prediction
        Z = self.model.predict(img_patches)

        # select the most likely class
        Z = (Z[:,0] < Z[:,1]) * 1
        
        # regroup patches into images
        return Z.reshape(X.shape[0], -1)

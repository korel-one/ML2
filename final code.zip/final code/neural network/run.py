from mask_to_submission import *

# generate submission from predicted groundtruth

submission_filename = 'submission.csv'
image_filenames = []
for i in range(1, 51):
    image_filename = 'testing/groundtruth/satImage_' + '%.3d' % i + '.png'
    image_filenames.append(image_filename)
masks_to_submission(submission_filename, *image_filenames)







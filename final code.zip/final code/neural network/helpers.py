import numpy as np

""" In order to preserve boundaries when traverse an image with patches 48x48,
    symmetric pad is applied.

    Input: data - groundtruth or RGB image
    Ouput: extended data
"""
def pad_image(data, padding):
    if len(data.shape) < 3:
        data = np.lib.pad(data, ((padding, padding), (padding, padding)), 'reflect')
    else:
        data = np.lib.pad(data, ((padding, padding), (padding, padding), (0,0)), 'reflect')
    return data

""" Crop image into overlapped patches

    Input: im - RGB image; w, h - 48x48; step - 16; padding - (48-2*16) 
    Output: list of overlapped patches of size w*h
"""
def img_crop(im, w, h, step, padding):
    assert len(im.shape) == 3
    list_patches = []
    imgwidth = im.shape[0]
    imgheight = im.shape[1]
    im = np.lib.pad(im, ((padding, padding), (padding, padding), (0,0)), 'reflect')
    for i in range(padding,imgheight+padding,step):
        for j in range(padding,imgwidth+padding,step):
            im_patch = im[j-padding:j+w+padding, i-padding:i+h+padding, :]
            list_patches.append(im_patch)
    return list_patches

""" Crop image into overlapped patches and convert it to the single list of patches

    Input: X - a list of RGB images; patch_size - overlapping patch size; step - 16; padding - 16
    Output: single list of patches for X
"""
def create_patches(X, patch_size, step, padding):
    img_patches = np.asarray([img_crop(X[i], patch_size, patch_size, step, padding) for i in range(X.shape[0])])
    img_patches = img_patches.reshape(-1, img_patches.shape[2], img_patches.shape[3], img_patches.shape[4])
    return img_patches